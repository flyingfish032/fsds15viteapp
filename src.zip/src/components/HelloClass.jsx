import React,{ Component} from 'react'

function Welcome(props) {
  return (
    <div>
      <h1>Welcome to the com {props.name}a.k.a{props.id}</h1>
      </div>
  )
}

export default Welcome