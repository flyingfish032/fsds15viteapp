import React from 'react'

function Welcome(props) {
  return (
    <div>Welcome {props.name}and{props.id}</div>
  )
}

export default Welcome