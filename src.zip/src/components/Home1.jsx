import React from 'react'

const Home1 = () => {
  return (
    <div>
        
        <h1>Home Page</h1>
        
    </div>
  )
}

export default Home1