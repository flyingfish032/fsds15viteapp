import React from 'react'
import "./Flexdemo.css"

function Flexdemo() {
  return (
    <>
    {/* <div className='container'>
          <div className='div1'>DIVISION1</div>    
          <div className='div2'>DIVISION2</div>    
          <div className='div3'>DIVISION3</div>    
          <div className='div4'>DIVISION4</div>    
          <div className='div5'>DIVISION5</div> 
          <div className='div1'>DIVISION1</div>    
          <div className='div2'>DIVISION2</div>    
          <div className='div3'>DIVISION3</div>    
          <div className='div4'>DIVISION4</div>    
          <div className='div5'>DIVISION5</div> 
          <div className='div1'>DIVISION1</div>    
          <div className='div2'>DIVISION2</div>    
          <div className='div3'>DIVISION3</div>    
          <div className='div4'>DIVISION4</div>    
          <div className='div5'>DIVISION5</div>    
            
    </div> */}

     <div className='container2'>
           <div className='div1'>DIVISION1</div>    
           <div className='div2'>DIVISION2</div>    
           <div className='div3'>DIVISION3</div>    
           <div className='div4'>DIVISION4</div>    
           <div className='div5'>DIVISION5</div> 
           <div className='div1'>DIVISION1</div>    
           <div className='div2'>DIVISION2</div>    
           <div className='div3'>DIVISION3</div>    
           <div className='div4'>DIVISION4</div>    
           <div className='div5'>DIVISION5</div> 
           <div className='div1'>DIVISION1</div>    
           <div className='div2'>DIVISION2</div>    
           <div className='div3'>DIVISION3</div>    
           <div className='div4'>DIVISION4</div>    
           <div className='div5'>DIVISION5</div>    
       
     </div>
</>
  )
}

export default Flexdemo