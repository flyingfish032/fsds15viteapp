import React from 'react'
import "./Login.css"
function Login() {

  return (
    <div class="login">
    <h2><u>Login</u></h2>
    <form>
        <div class="form">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" ></input>
        </div>
        <div class="form">
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" ></input>
        </div>
        <div class="button">
            <button type="submit">Submit</button>
            <button type="reset">Reset</button>
        </div>
    </form>

</div>
  )
}
export default Login 